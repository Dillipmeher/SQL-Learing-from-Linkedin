UPDATE Customer
SET Phone = '(501)343-2345'
WHERE CustomerId = 9999