SELECT *
FROM Customer
WHERE CustomerID = 9999;