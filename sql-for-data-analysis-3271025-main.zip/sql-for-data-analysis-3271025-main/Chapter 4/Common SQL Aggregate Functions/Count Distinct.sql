SELECT COUNT(DISTINCT CustomerID)
from Orders;