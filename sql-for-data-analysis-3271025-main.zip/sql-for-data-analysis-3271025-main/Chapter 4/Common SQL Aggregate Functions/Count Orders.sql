SELECT COUNT(CustomerID)
from Orders;