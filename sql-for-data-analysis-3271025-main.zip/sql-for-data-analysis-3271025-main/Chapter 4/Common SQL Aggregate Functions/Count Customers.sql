SELECT COUNT(CustomerID)
from Customer;