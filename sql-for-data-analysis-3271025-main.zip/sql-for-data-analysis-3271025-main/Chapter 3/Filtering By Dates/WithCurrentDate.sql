SELECT OrderID, CreationDate
FROM Orders
Where CreationDate > Now()
