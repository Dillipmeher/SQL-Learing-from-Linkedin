SELECT Year(CreationDate), 
Month(CreationDate), 
Day(CreationDate)
FROM Orders