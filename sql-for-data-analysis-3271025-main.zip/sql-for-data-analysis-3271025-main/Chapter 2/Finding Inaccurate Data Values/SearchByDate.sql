SELECT *
FROM Orders
WHERE CreationDate > "2016-01-06";