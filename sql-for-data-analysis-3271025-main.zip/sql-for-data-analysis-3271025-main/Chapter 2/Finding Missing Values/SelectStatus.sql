SELECT Status
from Salesperson;