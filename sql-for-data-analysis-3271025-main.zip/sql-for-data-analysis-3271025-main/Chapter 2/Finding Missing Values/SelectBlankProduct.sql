SELECT ProductCode
FROM Product
WHERE ProductName =' ';