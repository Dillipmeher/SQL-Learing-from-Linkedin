SELECT FirstName
FROM Customer
WHERE FirstName LIKE "% %";