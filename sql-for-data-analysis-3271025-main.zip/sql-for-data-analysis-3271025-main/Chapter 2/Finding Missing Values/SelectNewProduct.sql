SELECT *
FROM Product
WHERE ProductID = 17;