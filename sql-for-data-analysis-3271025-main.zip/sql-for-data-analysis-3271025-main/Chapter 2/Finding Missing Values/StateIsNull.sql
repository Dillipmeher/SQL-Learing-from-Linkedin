SELECT CustomerID,
  FirstName,
  LastName
FROM Customer
WHERE State IS NULL