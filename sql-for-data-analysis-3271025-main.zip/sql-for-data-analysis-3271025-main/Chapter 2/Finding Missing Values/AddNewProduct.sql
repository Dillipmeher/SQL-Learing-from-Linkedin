INSERT INTO Product (
    ProductID,
    ProductCode,
    ProductName,
    Size,
    Variety,
    Price,
    Status
  )
VALUES (
    17,
    'MWORG64',
    " ",
    64,
    'Orange',
    '0.00',
    'ACTIVE'
  );